from django.contrib import admin
from .models import Taskdata

admin.site.register(Taskdata) # Taskdata will appear on admin page
from django.apps import AppConfig


class ShowdataConfig(AppConfig):
    name = 'showdata'
